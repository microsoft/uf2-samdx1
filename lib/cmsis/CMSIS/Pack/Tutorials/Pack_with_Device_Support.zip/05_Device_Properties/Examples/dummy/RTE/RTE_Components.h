
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'dummy' 
 * Target:  'MVCM3250 Flash' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_Drivers_I2C0                /* Driver I2C0 */
        #define RTE_Drivers_I2C1                /* Driver I2C1 */
        #define RTE_Drivers_I2C2                /* Driver I2C2 */
#define RTE_Drivers_UART0               /* Driver UART0 */
        #define RTE_Drivers_UART1               /* Driver UART1 */
        #define RTE_Drivers_UART2               /* Driver UART2 */
        #define RTE_Drivers_UART3               /* Driver UART3 */
        #define RTE_Drivers_UART4               /* Driver UART4 */

#endif /* RTE_COMPONENTS_H */
